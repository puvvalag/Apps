﻿using System;
using System.Net;
using System.Json;
using System.IO;
using System.Collections.Generic;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Util;

namespace MusicDownload
{
	[Service]
	[IntentFilter(new String[]{"MusicDownload.MusicDownload.NewMusicService"})]
	public class NewMusicService : IntentService
	{
		IBinder binder;
	
		public const string MoviesUpdatedAction = "MoviesUpdated";
		public static string NewMoviesList;

		protected override void OnHandleIntent (Intent intent)
		{
			//var stockSymbols = new List<string> (){"AMZN", "FB", "GOOG", "AAPL", "MSFT", "IBM"};
			//var heading = new Heading (){ Title="Latest", Url = "http://www.mazamp3.com/feeds/posts/summary/-/New%20Mp3?max-results="+5+"&alt=json", Position=0};
			string movies = UpdateMovies ();

			var moviesIntent = new Intent (MoviesUpdatedAction); 
			// Change this to new movie 
			if (movies != string.Empty){
			NewMoviesList = "movies : "+movies + " static lstLatestMovies : " + MainActivity.lstLatestMovies.Count;
			if (MainActivity.lstLatestMovies.Count > 0) {
				foreach (var text in MainActivity.lstLatestMovies)
					NewMoviesList += text;
			}
			Console.Out.WriteLine("Calling show notification");
				SendOrderedBroadcast (moviesIntent, null);
			}
		}

		public override IBinder OnBind (Intent intent)
		{
			binder = new MovieServiceBinder (this);
			return binder;
		}
			

		public string GetJSONData(string url)
		{


			//string url = "http://dl.mazamp3.com/2014/06/ghatothkachudu-songs-free-download.html";

			string content = "";
			//var rxcui = "198440";
			var request = HttpWebRequest.Create(url);
			request.ContentType = "application/json";
			request.Method = "GET";

			using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
			{
				if (response.StatusCode != HttpStatusCode.OK)
					Console.Out.WriteLine("Error fetching data. Server returned status code: {0}", response.StatusCode);
				using (StreamReader reader = new StreamReader(response.GetResponseStream()))
				{
					content = reader.ReadToEnd();
					if(string.IsNullOrWhiteSpace(content)) {
						Console.Out.WriteLine("Response contained empty body...");
					}
					else {
						//Console.Out.WriteLine("Response Body: \r\n {0}", content);
					}


				}
			}
			return content;

		}


		public string UpdateMovies ()
		{
			List<TeluguMovie> results = null;
			var movieDataList = new List<TeluguMovie> ();
			string newMoviesToList = string.Empty;
			if (MainActivity.lstLatestMovies.Count > 0) {


				string content = GetJSONData ("http://www.mazamp3.com/feeds/posts/summary/-/New%20Mp3?max-results=4&alt=json");

				Console.Out.WriteLine ("Service side : Fetched JSON data");
				var json = JsonValue.Parse (content);
				// Breakdown the JSON content
				var node = json["feed"];
				node = node ["entry"];
				//NUM_ROWS = node.Count / NUM_COLS + 1;
				int i = 1;
				foreach (JsonValue movie in node) {
					var objMovie = new TeluguMovie ();

					// Movie Summary
					var movieSummary = movie ["summary"];
					movieSummary = movieSummary ["$t"];
					objMovie.Summary = movieSummary;

					//Thumbnail Image
					var movieImage = movie ["media$thumbnail"];
					movieImage = movieImage ["url"];
					objMovie.ThumnailUri = movieImage;

					//HTML page url
					var movieHTML = movie ["link"];
					movieHTML = movieHTML [2];
					movieHTML = movieHTML ["href"];
					objMovie.HtmlPage = movieHTML;

					objMovie.Summary = movieSummary.ToString ().Substring (0, movieSummary.ToString ().IndexOf ("|"));

					movieDataList.Add (objMovie);
					i++;
				}
			}
			Console.Out.WriteLine ("static lstLatestMovies : " + MainActivity.lstLatestMovies.Count);
			if (movieDataList.Count > 0) {
				foreach (var movie in movieDataList) {
					var matchedStr = MainActivity.lstLatestMovies.Find (item => item.Equals (movie.Summary));
					if (matchedStr == null) {
						newMoviesToList += movie.Summary;
					}
				}
			}
			Console.Out.WriteLine ("In service, updating movies");
			return newMoviesToList;
		}
	}

	public class MovieServiceBinder : Binder
	{
		NewMusicService service;

		public MovieServiceBinder (NewMusicService service)
		{
			this.service = service;
		}

		public NewMusicService GetMovieService ()
		{
			return service;
		}
	}
}

