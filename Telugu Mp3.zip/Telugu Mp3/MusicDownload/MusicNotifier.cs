﻿using System;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Util;

namespace MusicDownload
{
	[BroadcastReceiver]
	[IntentFilter(new string[]{NewMusicService.MoviesUpdatedAction}, Priority = (int)IntentFilterPriority.LowPriority)]
	public class MusicNotifier : BroadcastReceiver
	{
		public MusicNotifier ()
		{
		}

		public override void OnReceive (Context context, Intent intent)
		{
			var list = NewMusicService.NewMoviesList;
			/*list = list.Substring (list.IndexOf ("Movie Name"));
			try
			{
				list = list.Substring (0, list.IndexOf ("Category"));
			}
			catch (Exception)
			{
				list ="new";
			}*/
			Console.Out.WriteLine("In Notifier, list : " +NewMusicService.NewMoviesList);
			var nMgr = (NotificationManager)context.GetSystemService (Context.NotificationService);
			var notification = new Notification (Resource.Drawable.icon, list);
			var pendingIntent = PendingIntent.GetActivity (context, 0, new Intent (context, typeof(MainActivity)), 0);
			notification.SetLatestEventInfo (context, "Download some new music", "New albums available", pendingIntent);
			nMgr.Notify (0, notification);
			NewMusicService.NewMoviesList = string.Empty;
		}
	}

}

