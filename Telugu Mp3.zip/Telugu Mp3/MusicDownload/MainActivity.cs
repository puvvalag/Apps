﻿using System;
using System.Net;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Json;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Graphics;
using Android.Net;
using UrlImageViewHelper;

namespace MusicDownload
{

	[Activity (Label = "MusicDownload", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		int NUM_ROWS = 5;
		int NUM_COLS = 3;
		int Max_Results = 30;
		List<Heading> headingsList = null;
		Dictionary<string , List<TeluguMovie>>  dicTeluguMovieData = new Dictionary<string, List<TeluguMovie>>();
		MusicNotifier musicNotifier = null;
		Intent movieServiceIntent;
		MovieServiceBinder binder = null;
		bool isBound = false;
		public static List<string> lstLatestMovies = new List<string>();

		public MainActivity()
		{
			headingsList = new List<Heading> () {
				new Heading() { Title="Latest", Url = "http://www.mazamp3.com/feeds/posts/summary/-/New%20Mp3?max-results="+Max_Results+"&alt=json", Position=0},
				new Heading() { Title="Old", Url = "http://www.mazamp3.com/feeds/posts/summary/-/old%20is%20gold?max-results="+Max_Results+"&alt=json", Position=1},
				new Heading() { Title="Pop", Url = "http://www.mazamp3.com/feeds/posts/summary/-/Pop%2FRemix?max-results="+Max_Results+"&alt=json", Position=2},
				new Heading() { Title="Ilayaraja", Url = "http://www.mazamp3.com/feeds/posts/summary/-/Ilayaraja?max-results="+Max_Results+"&alt=json", Position=3},
				new Heading() { Title="Devotional", Url = "http://www.mazamp3.com/feeds/posts/summary/-/Devotional?max-results="+Max_Results+"&alt=json", Position=4},
				new Heading() { Title="Newly Updated", Url = "http://www.mazamp3.com/feeds/posts/summary/-/Update?max-results="+Max_Results+"&alt=json", Position=5},
			};
		}

		private GestureDetector _gestureDetector;
		private GestureListener _gestureListener;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);


			var connectivityManager = (ConnectivityManager)GetSystemService(ConnectivityService);

			var activeConnection = connectivityManager.ActiveNetworkInfo;
			if (activeConnection == null)
			{
				// we are not connected to a network.
				var connectionDialog = new AlertDialog.Builder(this);
				connectionDialog.SetMessage ("You are not connected to the Internet.");
				connectionDialog.SetNeutralButton("Ok", delegate {
				});
				connectionDialog.Show ();
				return;
			}


			/*var mobileState = connectivityManager.GetNetworkInfo(ConnectivityType.Mobile).GetState();
			if (mobileState == NetworkInfo.State.Connected)
			{
				// We are connected via WiFi

			}*/

			ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;
			SetContentView(Resource.Layout.Main);

			_gestureListener = new GestureListener();
			_gestureListener.LeftEvent += GestureLeft;
			_gestureListener.RightEvent += GestureRight;
			_gestureDetector = new GestureDetector(this, _gestureListener);


			for (var i = 0; i < headingsList.Count; i++) {

				ActionBar.Tab tab = ActionBar.NewTab ();
				var title = headingsList [i].Title;
				tab.SetText (title);
				//tab.SetIcon(Resource.Drawable.tab1_icon);
				var url = headingsList [i].Url;
				tab.TabSelected += (sender, args) => {
					var movieData = GetMovieData (title, url);
					AddTable (movieData);
				};
				ActionBar.AddTab (tab);

			}

			// Set our view from the "main" layout resource
			//SetContentView (Resource.Layout.Main);

			// Get our button from the layout resource,
			// and attach an event to it

			//var layout = FindViewById<LinearLayout> (Resource.Id.layoutLL);


			//Button button = FindViewById<Button> (Resource.Id.myButton);
			//var jsonText = FindViewById<EditText> (Resource.Id.jsonEditText);
			//AddButtonEvent (button);


			/*downloadButton.Click += (object sender, EventArgs e) => {
				//On "Download" button cick, download the link in browser


				var uri = Android.Net.Uri.Parse("http://dl69.unlimited9.com/0/omzl69djk7hxdn/Pilla%20Nuvvu%20Leni%20Jeevitham%20-%20(2014).zip");
				Intent browserIntent = new Intent(Intent.ActionView, uri);
				StartActivity(browserIntent);

			};*/

			movieServiceIntent = new Intent ("MusicDownload.MusicDownload.NewMusicService");
			musicNotifier = new MusicNotifier ();
		}


		protected override void OnStart ()
		{
			base.OnStart ();

			var intentFilter = new IntentFilter (NewMusicService.MoviesUpdatedAction){Priority = (int)IntentFilterPriority.HighPriority};
			RegisterReceiver (musicNotifier, intentFilter);

			var movieServiceConnection = new MovieServiceConnection (this);
			BindService (movieServiceIntent, movieServiceConnection, Bind.AutoCreate);

			ScheduleMovieUpdates ();
		}


		void ScheduleMovieUpdates ()
		{
			if (!IsAlarmSet ()) {
				var alarm = (AlarmManager)GetSystemService (Context.AlarmService);
				Console.Out.WriteLine ("alarm not set");
				var pendingServiceIntent = PendingIntent.GetService (this, 0, movieServiceIntent, PendingIntentFlags.CancelCurrent);
				alarm.SetRepeating (AlarmType.Rtc, 0, AlarmManager.IntervalHour, pendingServiceIntent);
				//alarm.SetRepeating (AlarmType.Rtc, 0, AlarmManager.IntervalHalfHour, pendingServiceIntent);
			} else {
				Console.Out.WriteLine ("alarm already set");
			}
		}


		bool IsAlarmSet ()
		{
			return PendingIntent.GetBroadcast (this, 0, movieServiceIntent, PendingIntentFlags.NoCreate) != null;
		}


		class MovieReceiver : BroadcastReceiver
		{
			public override void OnReceive (Context context, Android.Content.Intent intent)
			{
				//((MainActivity)context).GetMovieData ("Latest","http://www.mazamp3.com/feeds/posts/summary/-/New%20Mp3?max-results="+Max_Results+"&alt=json");
				Console.Out.WriteLine("Call Get movie data here");
				InvokeAbortBroadcast ();
			}
		}

		class MovieServiceConnection : Java.Lang.Object, IServiceConnection
		{
			MainActivity activity;

			public MovieServiceConnection (MainActivity activity)
			{
				this.activity = activity;
			}

			public void OnServiceConnected (ComponentName name, IBinder service)
			{
				var movieServiceBinder = service as MovieServiceBinder;
				if (movieServiceBinder != null) {
					var binder = (MovieServiceBinder)service;
					activity.binder = binder;
					activity.isBound = true;
				}
			}

			public void OnServiceDisconnected (ComponentName name)
			{
				activity.isBound = false;
			}
		}
		/*


		 */

		private void GestureRight()
		{
			ActionBar.Tab tab = ActionBar.SelectedTab;
			var heading = headingsList.Find (a => a.Title == tab.Text);
			var index = heading.Position == 0 ? 6 : heading.Position;
			ActionBar.GetTabAt (index - 1).Select();
			//Console.Out.WriteLine ("Swiped Left");
			/*if (TabHost.CurrentTab - 1 < 0)
			{
				TabHost.CurrentTab = TabHost.TabWidget.TabCount - 1;
			}
			else
			{
				TabHost.CurrentTab--;
			}*/
		}

		private void GestureLeft()
		{
			ActionBar.Tab tab = ActionBar.SelectedTab;
			var heading = headingsList.Find (a => a.Title == tab.Text);
			var index = heading.Position == 5 ? -1 : heading.Position;
			ActionBar.GetTabAt (index + 1).Select();


			//Console.Out.WriteLine ("Swiped Right");
			/*if (TabHost.CurrentTab + 1 >= TabHost.TabWidget.TabCount)
			{
				TabHost.CurrentTab = 0;
			}
			else
			{
				TabHost.CurrentTab++;
			}*/
		}

		public override bool DispatchTouchEvent(MotionEvent ev)
		{
			_gestureDetector.OnTouchEvent(ev);
			return base.DispatchTouchEvent(ev);
		}

		private List<TeluguMovie> GetMovieData(string title, string url)
		{
			if (dicTeluguMovieData.ContainsKey (title))
				return dicTeluguMovieData [title];
			var movieDataList = new List<TeluguMovie> ();
			//string content = GetJSONData ("http://www.mazamp3.com/feeds/posts/summary/-/New%20Mp3?max-results=30&alt=json");
			//string content = GetJSONData ("http://www.mazamp3.com/feeds/posts/summary/-/old%20is%20gold?max-results=40&alt=json");
			string content = GetJSONData (url);
			//Console.Out.WriteLine (content);
			var json = JsonValue.Parse (content);
			// Breakdown the JSON content
			var node = json["feed"];
			node = node ["entry"];
			NUM_ROWS = node.Count / NUM_COLS + 1;
			int i = 1;
			foreach (JsonValue movie in node) {
				var objMovie = new TeluguMovie ();

				// Movie Summary
				var movieSummary = movie ["summary"];
				movieSummary = movieSummary ["$t"];


				//Thumbnail Image
				var movieImage = movie ["media$thumbnail"];
				movieImage = movieImage ["url"];
				objMovie.ThumnailUri = movieImage;

				//HTML page url
				var movieHTML = movie ["link"];
				movieHTML = movieHTML [2];
				movieHTML = movieHTML ["href"];
				objMovie.HtmlPage = movieHTML;

				string details = movieSummary.ToString ().Substring (0, movieSummary.ToString ().IndexOf ("|"));
				objMovie.Summary = details;
				//Console.Out.WriteLine (details);
				//Console.Out.WriteLine (movieImage.ToString());
				//Console.Out.WriteLine (movieHTML.ToString());

				/*string htmlPage = GetJSONData (movieHTML);
				var result = htmlPage.Substring(htmlPage.IndexOf("http://dl.mazamp3.com/"),100);
				result = result.Substring(0,result.IndexOf("\""));
					Console.Out.WriteLine (result);*/
				if (title.Equals("Latest") && i < 4) {
					/*if (lstLatestMovies.Count > 0) {
						var itemFound = lstLatestMovies.Find (str => str.Equals (details));
						if (itemFound != null && itemFound != string.Empty) {
							lstLatestMovies.Add (details);
						}
					} else {*/
						lstLatestMovies.Add (details);
					//}
				}
				movieDataList.Add (objMovie);
				i++;
			}
			dicTeluguMovieData.Add (title, movieDataList);
			return movieDataList;

			//Console.Out.WriteLine (text.ToString());
			//list	Count=10	System.Collections.Generic.List<System.Json.JsonValue>
		}

	
		public enum NetworkStatus
		{
			NotReachable,
			ReachableViaCarrierDataNetwork,
			ReachableViaWiFiNetwork
		}

		private void AddTable(List<TeluguMovie> movieData)
		{
			TableLayout table = FindViewById<TableLayout> (Resource.Id.myTable);
			table.RemoveAllViewsInLayout ();
			var movieCount = 0;
			for (int row = 0; row != NUM_ROWS; row++) {
				TableRow tableRow = new TableRow (this);

				table.AddView (tableRow);

				for (int col = 0; col != NUM_COLS && movieCount < movieData.Count;col++) {
					var image = new ImageView (this);
					image.LayoutParameters  = new TableRow.LayoutParams (220, 220, 1);
					var uri = movieData [movieCount].ThumnailUri;

					//image.SetImageURI (Android.Net.Uri.Parse (uri));


					//var imageBitmap = GetImageBitmapFromUrl(uri);
					image.SetUrlDrawable(uri,Resource.Drawable.loading);
					var movie = movieData [movieCount];
					image.Click += delegate {
						DownloadAlbum(movie);
					};
					/*var button = new Button (this);
					button.LayoutParameters = new TableRow.LayoutParams (TableRow.LayoutParams.MatchParent, TableRow.LayoutParams.MatchParent, 1);
					Bitmap b = new Bitmap ();


					button.SetBackgroundResource()
					button.Text = "Button";
					tableRow.AddView (button);*/
					tableRow.AddView (image);
					movieCount++;
				}
			}
			if (table.ChildCount > 1) {
				table.Dispose ();
			}
		}

		private void DownloadAlbum(TeluguMovie movieData)
		{
			//Console.Out.WriteLine ("In download method");

			var downloadDialog = new AlertDialog.Builder(this);
			var movieSummary = movieData.Summary;
			movieSummary = movieSummary.Substring (movieSummary.IndexOf ("Movie Name"));
			try
			{
			movieSummary = movieSummary.Substring (0, movieSummary.IndexOf ("Category"));
			}
			catch (Exception)
			{
			}
			downloadDialog.SetMessage(movieSummary);
			downloadDialog.SetNeutralButton("Download", delegate 
				{
				//Get the first download page
				string htmlPage = GetJSONData (movieData.HtmlPage);
				string result = string.Empty;
				bool exceptionRaised = false;
				try
				{
					result = htmlPage.Substring(htmlPage.IndexOf("http://dl.mazamp3.com/"),100);
					result = result.Substring(0,result.IndexOf("\""));
				}
				catch(Exception)
				{
					exceptionRaised = true;
				}

				//Console.Out.WriteLine (result);

				//Get the download url
				if(!exceptionRaised)
				{
				htmlPage = GetJSONData (result);
				}

				var downloadUrl = htmlPage.Substring(htmlPage.IndexOf("tr_bq"),250);
				//Console.Out.WriteLine("before : " +downloadUrl);
				downloadUrl = downloadUrl.Substring(downloadUrl.IndexOf("http:"));
				downloadUrl = downloadUrl.Substring(0,downloadUrl.IndexOf("\""));
				//Console.Out.WriteLine (downloadUrl);

				var uri = Android.Net.Uri.Parse(downloadUrl);
				Intent browserIntent = new Intent(Intent.ActionView, uri);
				StartActivity(browserIntent);


				});
			downloadDialog.SetNegativeButton("Cancel", delegate {


			});

			// Show the alert dialog to the user and wait for response.
			downloadDialog.Show();
		

		}

		private Bitmap GetImageBitmapFromUrl(string url)
		{
			Bitmap imageBitmap = null;

			using (var webClient = new WebClient())
			{
				var imageBytes = webClient.DownloadData(url);
				if (imageBytes != null && imageBytes.Length > 0)
				{
					imageBitmap = BitmapFactory.DecodeByteArray(imageBytes, 0, imageBytes.Length);
				}
			}

			return imageBitmap;
		}

		/*public virtual void SetImageURI(Android.Net.Uri uri2){

			Android.Net.Uri uri;
			uri = uri2;
		}*/ 

		private void AddButtonEvent(Button button)
		{

			button.Click += delegate {
				//string url = "http://www.mazamp3.com/feeds/posts/summary/-/Update?max-results=5&alt=json-in-script";

			};
		}

		public string GetJSONData(string url)
		{


			//string url = "http://dl.mazamp3.com/2014/06/ghatothkachudu-songs-free-download.html";

			string content = "";
			//var rxcui = "198440";
			var request = HttpWebRequest.Create(url);
			request.ContentType = "application/json";
			request.Method = "GET";

			using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
			{
				if (response.StatusCode != HttpStatusCode.OK)
					Console.Out.WriteLine("Error fetching data. Server returned status code: {0}", response.StatusCode);
				using (StreamReader reader = new StreamReader(response.GetResponseStream()))
				{
					content = reader.ReadToEnd();
					if(string.IsNullOrWhiteSpace(content)) {
						Console.Out.WriteLine("Response contained empty body...");
					}
					else {
						//Console.Out.WriteLine("Response Body: \r\n {0}", content);
					}


				}
			}
			return content;

		}

	}
	public class Heading
	{
		public string Url {
			get;
			set;
		}

		public string Title {
			get;
			set;
		}
		public int Position {
			get;
			set;
		}
	}

	public class TeluguMovie
	{

		public string ThumnailUri {
			get;
			set;
		}

		public string HtmlPage {
			get;
			set;
		}

		public string DownloadUri {
			get;
			set;
		}
		public string MovieName {
			get;
			set;
		}
		public string Cast {
			get;
			set;
		}
		public string Music {
			get;
			set;
		}
		public string Summary {
			get;
			set;
		}


	}

}


